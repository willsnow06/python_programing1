import random

#1.	Create a list of strings with these “thought provoking” questions
questions = ['is a hot dog a sandwhich?', 'would you rather fight ten high schoolers or 50 fourth graders', 'what is your credit card number, expiration date, and three numbers on the back?']

#2.	Add a random function that relates a number too the list
value = random.randint(0, 2)

#3.	Print the input statement with the question
answer = input(f'{questions[value]}\n')

#4.	Append the input to the file
fo = open('output.txt', 'a')

fo.write(f'{answer}\n')

fo.close()
