#Welcome message
print('welcome the the pig latin converter. type text below.')
while 1 == 1:
  #Input function where the user types what they want to translate
 typed = input('type:\n')
 #Split that statement into a new function
 words = typed.split()
 #Use a for loop to target every word
 for word in words:
   #In that loop separate the first letter and add it to ‘ay’ and show the word without the first letter
   word = word[1:] + ' ' + word[0] + 'ay'
   #Return translated text
   print(word)